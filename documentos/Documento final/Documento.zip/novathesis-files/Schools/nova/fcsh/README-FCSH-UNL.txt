%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FCSH-NOVA
%% Faculdade de Ciências Sociais e Humanas
%% Universidade NOVA de Lisboa
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Reccomendations of options to be set/changed in “template.tex”:

  school=nova/fcsh,
  coverlang=pt,
  otherlistsat=back,
	aftercover=true,
	biblatex={
		…,
		style=bwl-FU,
		…,
	},

