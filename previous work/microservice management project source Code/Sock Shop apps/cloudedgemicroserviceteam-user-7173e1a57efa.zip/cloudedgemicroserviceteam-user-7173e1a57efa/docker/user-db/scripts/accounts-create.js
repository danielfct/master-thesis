db.createCollection("addresses");
db.createCollection("cards");
db.createCollection("customers");


